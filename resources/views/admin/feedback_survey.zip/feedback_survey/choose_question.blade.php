@extends('layout.admin')
{{-- Page title --}}
@section('title')
Message
@parent
@stop
{{-- page level styles --}}
@section('header_styles')

<!--     <link href="{{asset('dropzone/dist/dropzone.css')}}" rel="stylesheet"/>-->
<style type="text/css">
    #image_on_popup img{
        max-width: 100%;
        max-height: 100%;
    }
    .dataTables_filter{
        display:none !important;
    }
    .selected_parti_count {
        float: left;
        text-align: right !important;
        margin-left: 75px;
        border-right: 1px solid #999;
        padding-right: 30px;
    }
    .balence_margin {
        float: right;
    }
    #img {
    width: 21px;
    border: none;
    margin-left: -20px;
    margin-bottom: 91px;
    cursor: pointer;    position: absolute;
    top: 0;
    right: 76px;
}
</style>
@stop
{{-- Page content --}}
@section('inner_body')
<div class="row">
    <div class="col-lg-12 mb-3">
        @if(count($errors) > 0)
        @foreach ($errors->all() as $error)
        <div class="alert alert-card alert-danger">
            <strong class="text-capitalize">{{$error}}</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        @break
        @endforeach
        @endif

        <!-- @if(session()->has('message.level'))
        <div class="alert alert-card alert-{{ session('message.level') }}"> 
            <strong class="text-capitalize">{!! session('message.content') !!}</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        @endif -->
        <!--begin::form 2-->
        @if($question == null)
            {!! Form::open(['route' => 'store_question', 'files' => 'true', 'method' => 'post', 'class' => 'form-horizontal form-label-left' ]) !!}
            @else
            {!! Form::model($question,['route' => 'store_question', 'files' => 'true','method' => 'put', 'class' => 'form-horizontal form-label-left' ]) !!}
        @endif
        <!-- start SURVEY Form Layout-->
        <div class="card mb-4">
            <div class="card-header bg-transparent">
                <h3 class="card-title">Feedback Setting</h3>
            </div>
            <div class="card-body">
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">Background (color or image) <span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        <input type="file" id="question_form_background" name="question_form_background" class="form-control">
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-12">
                        <?php   
                        $src = $base_path."assets/images/user-placeholder.jpg";
                           $src =  ($question != null && $question->question_form_background != null) ? $base_path.$question->question_form_background : $src;
                        
                        ?>
                        <img src="<?php echo $src; ?>" id="question_bg" width="70px" >
                        @if (isset($question) && $question->question_form_background)
                            <img id="img" class="question_bg" src="{{asset('assets/images/stop.png')}}" alt="delete" onclick="removeImage('question_form_background')" >                            
                        @endif
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-12">
                        <div class="input-right-icon">
                            @php
                                $question_background_color = $question ? $question->question_background_color : '';
                            @endphp
                            {!! Form::text('question_background_color', $question_background_color,['class' => 'form-control','id' => 'question_bg_color']) !!}
                            <span class="span-right-input-icon">
                                <i class="ul-form__icon i-Arrow-Down"></i>
                            </span>
                        </div>    
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">Question Form Logo <span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        <input type="file" id="question_form_logo" name="question_form_logo" class="form-control">
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-12">
                        <?php   $src = $base_path."assets/images/user-placeholder.jpg";
                            $src =  ($question != null && $question->question_form_background != null) ? $base_path.$question->question_form_background : $src;
                            ?> 
                                <img src="<?php echo $src; ?>" id="question_logo" width="70px">
                            @if (isset($question) && $question->question_form_logo)
                                <img id="img" class="question_logo" src="{{asset('assets/images/stop.png')}}" alt="delete" onclick="removeImage('question_form_logo')" >
                                <!-- <i class="i-Close-Window nav-icon font-weight-bold" aria-hidden="true" onclick="removeImage('question_form_logo')" ></i> -->
                            @endif
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">Logo size <span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        {!! Form::number('logo_size', null,['class' => 'form-control','max' => '150']) !!}
                    </div>
                </div>
                <div class="form-group row">
                    @php
                        $pop_up_rating = $question ? $question->rating_pop_up : '';
                    @endphp
                    {!! Form::label('Minimum rating for pop-up','Minimum rating for pop-up:*', ['class' =>'ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right']) !!}
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        {!! Form::select('rating_pop_up',array('1' => '1','2'=> '2','3' => '3','4' => '4' , '5' => '5'),$pop_up_rating,['class'=>'form-control']) !!}
                    </div>
                </div>
            </div>
        </div>
        <!-- end survey Form Layout-->


        <!-- start SURVEY Form Layout-->
        <div class="card mb-4">
            <div class="card-header bg-transparent">
                <h3 class="card-title">Choose for Pop-Up label</h3>
            </div>
            <div class="card-body reason_field">
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">Enter day for change complain status<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        @if ($errors->has('complain_status_day'))
                            <div style="color: red;">{{ $errors->first('complain_status_day') }}</div>
                        @endif
                        {!! Form::number('complain_status_day', null,['class' => 'form-control','min' => '1']) !!}
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">Complain button name <span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        @if ($errors->has('complain_button_name'))
                            <div style="color: red;">{{ $errors->first('complain_button_name') }}</div>
                        @endif
                        {!! Form::text('complain_button_name', null,['class' => 'form-control']) !!}
                    </div>
                </div>
                <div class="form-group row">
                    {!! Form::label('complain_button_text_size','Complain button text size:*', ['class' =>'ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right']) !!}
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        @php 
                        $complain_button_text_size = $question ? $question->complain_button_text_size :  ''
                        @endphp
                        <div class="input-right-icon">
                            <select name="complain_button_text_size" class="form-control">
                                <option value="">Select Font Size</option>
                                    @for($i = 1; $i <= 30; $i++)
                                <?php 
                                    $selected = ''; 
                                    if(isset($question) && $complain_button_text_size == $i.'px'){

                                        $selected = 'selected';
                                    }
                                    
                                ?>
                                <option value="{{$i}}px" <?php echo $selected ?> > {{$i}}px</option>
                                @endfor
                            </select>
                            <span class="span-right-input-icon">
                            <i class="ul-form__icon i-Arrow-Down"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    {!! Form::label('complain_button_text_color','Select text color for complain button:*', ['class' =>'ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right']) !!}
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        {!! Form::text('complain_button_text_color', null,['class' => 'form-control','id' => 'complain_button_text_color']) !!}
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Thank you message<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        @if ($errors->has('thank_you_message'))
                            <div style="color: red;">{{ $errors->first('thank_you_message') }}</div>
                        @endif
                        {!! Form::text('thank_you_message', null,['class' => 'form-control']) !!}
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Complain Pop-up title<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        @if ($errors->has('thank_you_message'))
                            <div style="color: red;">{{ $errors->first('complain_title') }}</div>
                        @endif
                        {!! Form::text('complain_title', null,['class' => 'form-control']) !!}
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Reason Pop-up title<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                            @if ($errors->has('thank_you_message'))
                            <div style="color: red;">{{ $errors->first('reason_title') }}</div>
                        @endif
                        {!! Form::text('reason_title', null,['class' => 'form-control']) !!}
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Choose Pop-up label language?<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2 d-inline-flex">
                        <label class="radio radio-primary  mr-2">
                            {{ Form::radio('label_language', 'english' , true) }} English
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary  mr-2">
                            {{ Form::radio('label_language', 'arabic' , false) }} Arabic
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Choose reason apperance.<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2 d-inline-flex">
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('reason_appear', 'right' , true) }} Right
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('reason_appear', 'left' , false) }} Left
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('reason_appear', 'center' , false) }} Center
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="form-group row">
                    {!! Form::label('reason_font_size','Select font size for reason:*', ['class' =>'ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right']) !!}
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        @php 
                        $complain_button_text_size = $question ? $question->complain_button_text_size :  ''
                        @endphp
                        <div class="input-right-icon">
                            <select name="reason_font_size" class="form-control">
                                    <option value="">Select Font Size</option>
                                @for($i = 1; $i <= 30; $i++)
                                    <?php 
                                        $selected = ''; 
                                        if(isset($question) && $question->reason_font_size == $i.'px'){

                                            $selected = 'selected';
                                        }
                                        
                                    ?>
                                    <option value="{{$i}}px" <?php echo $selected ?> >{{$i}}px</option>
                                @endfor
                            </select>
                            <span class="span-right-input-icon">
                            <i class="ul-form__icon i-Arrow-Down"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    {!! Form::label('reason_text_color','Select text color for reason:*', ['class' =>'ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right']) !!}
                    
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        @php 
                        $complain_button_text_size = $question ? $question->complain_button_text_size :  ''
                        @endphp
                        <div class="input-right-icon">
                            {!! Form::text('reason_text_color', null,['class' => 'form-control','id' => 'reason_text_color']) !!}
                            <span class="span-right-input-icon">
                            <i class="ul-form__icon i-Arrow-Down"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Do you want to show Full Screen Button?<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2 d-inline-flex">
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('fullscreen_button', '1' , true) }} Yes
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('fullscreen_button', '0' , false) }} No
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Do you want to show complain button?<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2 d-inline-flex">
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('complain_button', '1' , true) }} Yes
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('complain_button', '0' , false) }} No
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Do you want to show Question in Sequence?<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2 d-inline-flex">
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('question_sequence', '1' , false) }} Yes
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('question_sequence', '0' , true) }} No
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                    Select emoji and rating question size?<span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2 d-inline-flex">
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('emoji_and_rating_size', 'large' , true) }} Large
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('emoji_and_rating_size', 'medium' , false) }} Medium
                            <span class="checkmark"></span>
                        </label>
                        <label class="radio radio-primary mr-2">
                            {{ Form::radio('emoji_and_rating_size', 'small' , false) }} Small
                            <span class="checkmark"></span>
                        </label>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                        Select color for complain button :
                    <span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        <div class="input-right-icon">
                            {{Form::text('complain_button_color',null,['class' => 'form-control','id' => 'complain_button_color'])}}
                            <span class="span-right-input-icon">
                            <i class="ul-form__icon i-Arrow-Down"></i>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                        Select color for complain and reason header :
                    <span class="required">*</span></label>
                    <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                        <div class="input-right-icon">
                            {{Form::text('complain_header_color',null,['class' => 'form-control','id' => 'complain_header_color'])}}
                            <span class="span-right-input-icon">
                            <i class="ul-form__icon i-Arrow-Down"></i>
                            </span>
                        </div>
                    </div>
                </div>
                @if(count($feedback_reason) == 0)
                
                    <div class="form-group row">
                        <label for="staticEmail" class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">
                        Add reason for feedback.
                        <span class="required">*</span></label>
                        <div class="col-lg-5 col-md-5 col-sm-5 mb-2">
                            {!! Form::hidden('feedback_reason',$feedback_reason,['id' => 'feedback_reason']) !!}
                            {!! Form::text('reason[]', null,['class' => 'form-control','placeholder' => 'Enter reason','id' => 'reason_1']) !!}
                            {!! Form::button('Add More',['class' => 'btn btn-success btn-sm', 'id' => 'add']) !!}
                        </div>
                    </div>
                @endif
            </div>
            <div class="card-footer">
                <div class="mc-footer">
                    <div class="row text-right">
                        <div class="col-sm-4"></div>
                        <div class="ol-lg-6 text-left">
                            <input type="submit"  class="btn btn-primary float-right" value="Save">
                        </div>
                    </div>      
                </div>
            </div>
        </div>
        <!-- end survey Form Layout-->
        {!! Form::close() !!}
    </div>    
</div>
  
@stop

{{-- page level scripts --}}
@section('footer_scripts')

@include('admin.participant.more_detail') 

<script type="text/javascript">

var dataTable;
var extraData;
var selected_question = [];
var sendAll = 0;

// var template = Handlebars.compile($("#details-template").html());
// Handlebars.registerHelper('ifCond', function(v1, v2, options) {
//   if(v1 === v2) {
//     return options.fn(this);
//   }
//   return options.inverse(this);
// });

var columns = [
    {data: 'rownum', name: 'rownum'},
    {data: 'checkbox', name: 'checkbox'},
    {data: 'question', name: 'question'},
];

var ajaxUrl = '{!! route('show_feedback_survey') !!}'; //Url of ajax datatable where you fetch data

//It may be empty array
var columnDefs = [
    {
        "targets": 0,
        "orderable": true,
        "class": "text-center",
    },
    {
        "targets": 1,
        "orderable": false,
        "class": "text-center"
    },
    {
        "targets": 2,
        "orderable": true,
        "class": "text-center"
    },
    
];
</script> 
<script type="text/javascript">
    $('#title_color').colorpicker({});
    $('#question_bg_color').colorpicker({});
    $('#reason_text_color').colorpicker({});
    $('#complain_button_text_color').colorpicker({});
    $('#complain_header_color').colorpicker({});
    $('#complain_button_color').colorpicker({});
    
</script>
<!-- for image uploading -->
<script type="text/javascript">
    $(document).ready(function(){
        
        $("#question_form_logo").change(function () {
        
            readURL(this);
        });

        $("#question_form_background").change(function () {
            readURLBG(this);
        });
    })
    function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#question_logo').attr('src', e.target.result);
            srcData = e.target.result;
        }

        reader.readAsDataURL(input.files[0]);
    }
}
function readURLBG(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#question_bg').attr('src', e.target.result);
            srcData = e.target.result;
        }

        reader.readAsDataURL(input.files[0]);
    }
}
</script>
<script type="text/javascript">
       
        $(document).on('change','.select-question',function(e){
            //debugger;
            var tr = $(this).closest('tr');
            var row = dataTable.row(tr).data();

            var countCheckedCheckboxes = $('.select-question:checked').length;
            if(countCheckedCheckboxes>0){
                $('.selected_parti_count').html("<h2>Selected question: "+ countCheckedCheckboxes+ "</h2>");
            }else{
                $('.selected_parti_count').html("");
            }

            if($(this).is(":checked")) {
                selected_question.push(row.id);
            }else{
                selected_question.pop(row.id);
            }
            $('#question_id').val(selected_question);
        });

        $(document).on('change','#select-all-question',function(e){
            
            if($(this).is(":checked")) {
                sendAll = 1;
                $('.select-question').prop('checked',true);
            }else{
                sendAll = 0;
                $('.select-question').prop('checked',false);
            }
        });
</script>
<script>
function removeImage (field) {
    if (field == 'question_form_background') {
        $('.question_bg').hide()
        $('#question_bg').hide()
    } else {
        $('.question_logo').hide()
        $('#question_logo').hide()
    }
    var removeField = field;
    var url = "{{route('removeImage')}}";
    $.ajax({
            type: "POST",
            url: url,
            data: {
            "_token": "{{ csrf_token() }}",
            'field' : removeField,
            },
            success: function(resp){
            if (field == 'question_form_background') {
                $('#question_bg').attr('src',"{{asset('assets/images/user-placeholder.jpg')}}")
                $('#question_bg').show()
               
            } else {
                $('#question_logo').attr('src',"{{asset('assets/images/user-placeholder.jpg')}}")
                $('#question_logo').show()
            }
            },
});
}
</script>
<script type="text/javascript">
    $(document).ready(function(){
        
        var feedback_reason = <?php echo $feedback_reason ?>;
        
        if(feedback_reason.length > 0){
            $.each(feedback_reason, function(i,elem){

                if(i == 0){
                    
                    // $('#reason_1').val(elem.feedback_reason)
                    $('.reason_field').append('<div class="form-group row"><label class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right">Add reason for feedback</label><div id="reason_'+i+'" class="form-group col-lg-5 col-md-5 col-sm-5 mb-2"><input type="text" name="reason[]" value="'+elem.feedback_reason+'" class="form-control " placeholder="Enter Reason"></div><div class="col-sm-2 col-md-2 col-lg-2 mb-2"><button type="button" class="btn btn-success btn-sm" id="add">Add more</button></div></div>')
                }else{
                    $('.reason_field').append('<div class="form-group row" id="reason_'+i+'"><label class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right"></label><div  class="col-lg-5 col-md-5 col-sm-5 mb-2"><input type="text" name="reason[]" class="form-control " value="'+elem.feedback_reason+'" placeholder="Enter Reason"></div><div class="col-sm-2 col-md-2 col-lg-2 mb-2"><button type="button" id="'+i+'" class="btn btn-danger btn-sm remove_btn">remove</button></div></div>')
                }
            })
        }

        var i = 1;
        $('#add').click(function(){
            
            i++;
        $('.reason_field').append('<div class="form-group row"  id="reason_'+i+'"><label class="ul-form__label col-lg-3 col-md-3 col-sm-3 col-form-label text-right"></label><div class="col-lg-5 col-md-5 col-sm-5 mb-2" ><input type="text" name="reason[]" class="form-control " placeholder="Enter Reason"></div><div class="col-sm-2 col-md-2 col-lg-2 mb-2"><button type="button" id="'+i+'" class="btn btn-danger btn-sm remove_btn">remove</button></div></div>')
        })
        $(document).on('click','.remove_btn' , function(){

            var button_id = $(this).attr("id");
            $('#reason_'+button_id).remove();

        })
    })
</script>
@include('datatable.alert_js')
@stop

