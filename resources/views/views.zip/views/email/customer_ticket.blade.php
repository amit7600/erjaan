<p>Dear {{$customer_name}},</p>

<p>A Ticket is created for you.</p>
<p>Followed by And currently status of your ticket is: <strong>{{$ticket_status}}</strong></p>

<p>Best Regards,</p>
Blackbelt 360 Team

<!-- <p><img alt="" src="{{url('/')}}/front/images/breadcrum-face.png" style=" width:350px" /></p> -->
<hr style="board:1px solid #ccc">
<p>{{$site_title}} </p>
<p>connecting business & people.</p>
<table align="center" border="0" cellspacing="0" cellpadding="0" style="margin:45px 0 0;">
    <tr style="text-align: center;">   
        <td style="display: inline-block; margin:0 0 7px;">
            <ul style="margin: 0px; padding: 0px; width: 210px;">
                <li style="display:inline-block; float: left; margin: 4px 0 0;"><label style="color: #2d3235; font-size: 13px; font-weight: lighter; margin: 0;">Follow Us on:</label></li>
                <li style=" display:inline-block; float: left;"><a href="javascript:void(0)"><i class="fa  fa-facebook"></i></a></li>
                <li style=" display:inline-block; float: left;"><a href="javascript:void(0)"><i class="fa  fa-twitter"></i></a></li>
                <li style=" display:inline-block; float: left;"><a href="javascript:void(0)"><i class="fa  fa-pinterest-p"></i></a></li>
                <li style=" display:inline-block; float: left;"><a href="javascript:void(0)"><i class="fa  fa-instagram"></i></a></li>
                <li style=" display:inline-block; float: left;"><a href="javascript:void(0)"><i class="fa  fa-youtube-play"></i></i></a></li>
            </ul>
        </td>
    </tr>
    <tr>
        <td style="display: inline-block; margin:0;">
            <p style="font-family: arial; color: #85939d;  font-size: 13px; margin: 0; text-align: center; font-weight: lighter;">© Copyright 2017. All Rights reserved.
                <a style="font-family: arial; color: #85939d;  font-size: 13px;text-decoration: none;font-weight: lighter;" href="javascript:void(0)">Disclaimer</a> | <a style="font-family: arial; color: #85939d;  font-size: 13px; margin: 0;text-decoration: none; font-weight: lighter;" href="javascript:void(0)"> Terms & Conditions</a>
            </p>
        </td>
    </tr>
</table>