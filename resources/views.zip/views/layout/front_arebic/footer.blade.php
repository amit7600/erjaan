 <!--Footer Section Start -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="copyright">
                        <p>حقوق الفكرة و المحتوى يعود لشركة الأرجان 2018</p>
                    </div>
                </div>
                <div class="col-sm-6 text-right" style="display:none;">
                    <ul class="social">
                        <li>
                            <a href="javascript:void(0);">
                                <i class="fa fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <i class="fa fa-pinterest"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </footer>
        <!--End of Tawk.to Script-->
    </body>
</html>