 <!--Footer Section Start -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="copyright">
                        <p>© Copyrights 2018 All rights reserved</p>
                    </div>
                </div>
                <div class="col-sm-6 text-right">
                    <ul class="social">
                        <li>
                            <a href="javascript:void(0);">
                                <i class="fa fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <i class="fa fa-pinterest"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </footer>
        <!--End of Tawk.to Script-->
    </body>
</html>