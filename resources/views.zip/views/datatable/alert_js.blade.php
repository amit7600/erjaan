<script type="text/javascript">
$(document).on('click', 'a.delete_data', function (e) {
        e.preventDefault(); // does not go through with the link.
        var url = $(this).attr('data-href');
        swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0CC27E',
            cancelButtonColor: '#FF586B',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success mr-5',
            cancelButtonClass: 'btn btn-danger',
            buttonsStyling: false
        }).then(function () {
            $.ajax({
                url: url,
                type: 'post',
                dataType: 'json',
                data: {
                    _method: 'delete',
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function (resp) {
                    if (resp.status) {
                        dataTable.ajax.reload();
                    }
                    swal(
                        'Deleted!',
                        resp.message,
                        'success'
                    )
                },
                error: function () {
                    swal(
                        'Deleted!',
                        'Something went wrong !!!',
                        'Error'
                    )
                }
            });
        }, function (dismiss) {
            // dismiss can be 'overlay', 'cancel', 'close', 'esc', 'timer'
            if (dismiss === 'cancel') {
                swal(
                    'Cancelled',
                    'Your imaginary file is safe :)',
                    'error'
                )
            }
        })
    });


    $(document).on('click', 'a.change_data', function (e) {
        e.preventDefault(); // does not go through with the link.
        var url = $(this).attr('data-href');
        swal({
            title: 'Are you sure?',
            text: "You are change this status?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0CC27E',
            cancelButtonColor: '#FF586B',
            confirmButtonText: 'Yes, change it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success mr-5',
            cancelButtonClass: 'btn btn-danger',
            buttonsStyling: false
        }).then(function () {
            $.ajax({
                url: url,
                type: 'post',
                dataType: 'json',
                data: {
                    _method: 'delete',
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function (resp) {
                    if (resp.status) {
                        dataTable.ajax.reload();
                    }
                    swal(
                        'Changed!',
                        resp.message,
                        'success'
                    )
                },
                error: function () {
                    swal(
                        'Changed!',
                        'Something went wrong !!!',
                        'Error'
                    )
                }
            });
        }, function (dismiss) {
            // dismiss can be 'overlay', 'cancel', 'close', 'esc', 'timer'
            if (dismiss === 'cancel') {
                swal(
                    'Cancelled',
                    'Your imaginary file is safe :)',
                    'error'
                )
            }
        })
        
    });
    $(document).on('click', 'a.active_inactive_data', function (e) {
        e.preventDefault(); // does not go through with the link.
        var url = $(this).attr('data-href');
        bootbox.confirm("Are you sure?", function (confirmed) {
            if (!confirmed) {
                bootbox.hideAll()
                return false;
            }

            //Ajax Start Here Delete Routes
            $.ajax({
                url: url,
                type: 'get',
                dataType: 'json',
                success: function (resp) {
                    if (resp.status) {
                        dataTable.ajax.reload();
                    }
                    bootbox.alert(resp.message);
                },
                error: function () {
                    bootbox.alert("Something went wrong !!!");
                }
            });
        });
    });
    $(document).ready(function(){
        var sessionData = "{{Session::get('message.level')}}"
        if(sessionData == "success"){
            swal({
                type: 'success',
                title: 'Success!',
                text: "{!! session('message.content') !!}",
                buttonsStyling: false,
                confirmButtonClass: 'btn btn-lg btn-success'
            })
        }
        
        
    });
</script>    