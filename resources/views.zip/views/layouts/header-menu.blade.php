<div class="main-header">
    <div class="logo">
        <?php
        $image_logo = Auth::user()->user_logo;
        $image_logo = !empty($image_logo) ? $image_logo : "";
        if (!file_exists($image_logo)) {
            $image_logo = "uploads/logo.png";
        }
        $image_logo = url('/') . '/' . $image_logo;
        ?>
        <a href="{{route('admin')}}" class="site_title">
            <span>
                <img src="{{ $image_logo }}">
            </span>
        </a>
    </div>

    <div class="menu-toggle">
        <div></div>
        <div></div>
        <div></div>
    </div>
    <div style="margin: auto"></div>

    <div class="header-part-right">
        <!-- Full screen toggle -->
        <i class="i-Full-Screen header-icon d-none d-sm-inline-block" data-fullscreen></i>
         {{-- RTL Spinner Start--}}
         <div class="dropdown">
                <div class="badge-top-container" id="dropdownNotification" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="i-Font-Window text-30  mr-2  ml-2" ></i>
                </div>
                <!-- Notification dropdown -->
                <div class="dropdown-menu rtl-ps-none dropdown-menu-right notification-dropdown" aria-labelledby="dropdownNotification" data-perfect-scrollbar data-suppress-scroll-x="true">
                    <div class="dropdown-item d-flex">
                        <div class="notification-icon">
                            <i class="i-Alpha text-primary mr-1"></i>
                        </div>
                        <div class="notification-details flex-grow-1">
                            <p class="m-0 d-flex align-items-center"> 
                                <span class="badge badge-pill badge-primary ml-1 mr-1"></span>
                                <span class="flex-grow-1"></span>
                                <span class="text-small text-muted ml-auto"></span>
                                <div class="card-body mt-4">
                                    <label class="checkbox checkbox-primary">
                                        <input type="checkbox" id="rtl-checkbox">
                                        <span>Enable RTL</span>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            {{-- RTL Spinner End--}}
        @if($role == 0 || $permission_data->quick_add_participants_button == 1)
            <button class="btn btn-primary btn-icon m-1" id="quick_add_participant"  data-toggle="modal" data-target="#myModal">
                <span class="ul-btn__icon"><i class="i-Gear-2"></i></span> 
                <span class="ul-btn__text">Quick add Participant</span>
            </button>
        @endif
        <!-- User avatar dropdown -->
        @if(!empty($menu_type))
            <div class="dropdown">
                <div  class="user col align-self-end">
                    <?php
                    $image = Auth::user('user_image');
                    $image = !empty($image->user_image) ? $image->user_image : "";
                    if (!file_exists($image)) {
                        $image = "uploads/user_image.jpg";
                    }
                    $image = url('/') . '/' . $image;
                    ?>

                    <img src="{{$image}}" id="userDropdown" alt="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <i class="i-Lock-User mr-1"></i> {{ Auth::user()->name }}
                        </div>
                        <a class="dropdown-item" href="{{route('get_admin_profile')}}" >Profile</a>
                        <a class="dropdown-item" href="{{route('logout')}}">Log Out</a>
                    </div>
                </div>
            </div>
        @endif
       
       
    </div>

</div>
<!-- header top menu end -->
<style>
.changeCursor span.span-right-input-icon{
    left: 10px;
    right: auto;
}
.changeCursor .emotion-Icon{
    right : 0px;
}

</style>

<script>
$(document).ready(function () {
    $('#rtl-checkbox').on('click', function(e) {
    $('body').toggleClass('changeCursor');
    e.stopPropagation();
});
})

</script>